export default class FormValidator {
  constructor(settings, formElement) {
    this._form = formElement;
    this._settings = settings;
  }

  _showInputError(inputEl) {
    const { inputErrorClass, errorClass } = this._settings;
    const errorMessageEl = this._form.querySelector(`#${inputEl.id}-error`);
    inputEl.classList.add(inputErrorClass);
    errorMessageEl.textContent = inputEl.validationMessage;
    errorMessageEl.classList.add(errorClass);
  }

  _hideInputError(inputEl) {
    const { inputErrorClass, errorClass } = this._settings;
    const errorMessageEl = this._form.querySelector(`#${inputEl.id}-error`);
    inputEl.classList.remove(inputErrorClass);
    errorMessageEl.textContent = "";
    errorMessageEl.classList.remove(errorClass);
  }

  _checkInputValidity(inputEl) {
    if (!inputEl.validity.valid) {
      this._showInputError(inputEl);
    } else {
      this._hideInputError(inputEl);
    }
  }

  _toggleButtonState(inputEls, submitButton) {
    const { inactiveButtonClass } = this._settings;
    const hasInvalid = Array.from(inputEls).some(
      (input) => !input.validity.valid
    );
    if (hasInvalid) {
      submitButton.classList.add(inactiveButtonClass);
      submitButton.disabled = true;
    } else {
      submitButton.classList.remove(inactiveButtonClass);
      submitButton.disabled = false;
    }
  }

  _setEventListeners() {
    const inputEls = this._form.querySelectorAll(this._settings.inputSelector);
    const submitButton = this._form.querySelector(
      this._settings.submitButtonSelector
    );

    this._toggleButtonState(inputEls, submitButton);

    inputEls.forEach((inputEl) => {
      inputEl.addEventListener("input", () => {
        this._checkInputValidity(inputEl);
        this._toggleButtonState(inputEls, submitButton);
      });
    });
  }

  enableValidation() {
    this._form.addEventListener("submit", (e) => e.preventDefault());
    this._setEventListeners();
  }
}

const settings = {
  formSelector: ".modal__form",
  inputSelector: ".modal__input",
  submitButtonSelector: ".modal__submit-button",
  inactiveButtonClass: "modal__submit-button_disabled",
  inputErrorClass: "modal__input_type_error",
  errorClass: "modal__error_visible",
};

const editForm = document.querySelector("#profile-edit-form");
const addForm = document.querySelector("#add-card-form");

//const editFormValidator = new FormValidator(settings, profileEditForm);
//editFormValidator.enableValidation();
//const addFormValidator = new FormValidator(settings, addCardFormElement);
//addFormValidator.enableValidation();
