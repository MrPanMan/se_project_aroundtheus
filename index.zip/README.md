Project 3: Around The U.S.

Overview

A social media site using grid display and media queries to make the UI appear nice on different sized screens

for the design the page was made using figma
the css incorporates grid display for the profile and the picture cards
to insure a pleasent UI on different screen sizes media queries was used at max-width: 480px and 320px

This project is made so all the elements are displayed correctly on popular screen sizes. We recommend investing more time in completing this project, since it's more difficult than previous ones.

[Link to the project on Figma](https://www.figma.com/file/ii4xxsJ0ghevUOcssTlHZv/Sprint-3%3A-Around-the-US?node-id=0%3A1)

[link to image](../se_project_aroundtheus/images/Screenshot%202024-09-15%20174401.png)

[link to image](../se_project_aroundtheus/images/Screenshot%202024-09-15%20174432.png)

[link to video](https://youtu.be/XST_Y8v81MM)

[link to github pages](https://MrPanMan.github.io/se_project_aroundtheus/)
